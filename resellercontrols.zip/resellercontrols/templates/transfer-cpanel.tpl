{* transfer-cpanel.tpl — IT FOR NEPAL Reseller Controls *}

{if $response.error}
<div class="alert alert-danger">
    <i class="fa fa-exclamation-circle me-2"></i>{$response.error}
</div>
{/if}

{if $response.success}
<div class="alert alert-success">
    <i class="fa fa-check-circle me-2"></i>{$response.success}
</div>
{/if}

<p class="text-muted mb-3">
    Use this tool to transfer a cPanel account from a remote server into your reseller WHM space.
    <strong>Make sure the account exists on the remote server and you have valid credentials.</strong>
</p>

<form method="post" action="" class="needs-validation" novalidate id="transfer-form">
    {* CSRF token *}
    {if $token}
        <input type="hidden" name="token" value="{$token}">
    {/if}

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fa fa-file-import me-2 text-success"></i> Transfer cPanel Account
            </h5>
            <span class="badge bg-secondary">Reseller Tool</span>
        </div>
        <div class="card-body">

            <div class="mb-3">
                <label for="hostname" class="form-label">Remote Server Hostname or IP</label>
                <input type="text" id="hostname" name="hostname" class="form-control"
                       value="{if isset($smarty.post.hostname)}{$smarty.post.hostname|escape}{/if}"
                       placeholder="e.g. server.example.com or 192.168.1.100" required autocomplete="off">
                <div class="invalid-feedback">Please enter the remote server hostname or IP.</div>
            </div>

            <div class="mb-3">
                <label for="username" class="form-label">cPanel Username</label>
                <input type="text" id="username" name="username" class="form-control"
                       value="{if isset($smarty.post.username)}{$smarty.post.username|escape}{/if}"
                       placeholder="Enter the cPanel username on the remote server" required autocomplete="off">
                <div class="invalid-feedback">Please enter the cPanel username.</div>
            </div>

            <div class="mb-3" id="field-password">
                <label for="password" class="form-label">cPanel Password</label>
                <input type="password" id="password" name="password" class="form-control"
                       placeholder="Enter the cPanel password" required autocomplete="new-password">
                <div class="invalid-feedback">Please enter the password.</div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-play me-1"></i> Start Transfer
                </button>
                <a class="btn btn-light" href="index.php?m=resellercontrols&id={$serviceID}">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </a>
            </div>

        </div>
    </div>
</form>

<hr class="my-4">

<div class="d-flex justify-content-between align-items-center mb-2">
    <h5 class="mb-0"><i class="fa fa-list me-2 text-muted"></i> Transfer History</h5>
    <button id="clear-history-btn" class="btn btn-sm btn-outline-danger">
        <i class="fas fa-trash-alt me-1"></i> Clear History
    </button>
</div>

<div id="transfer-cards" class="row g-2">
{if !empty($transfers)}
    {foreach from=$transfers item=transfer}
    <div class="col-12 col-md-6 col-lg-4">
        <div class="card h-100 shadow-sm tf-card" data-status="{$transfer->status|lower}">
            <div class="card-header d-flex justify-content-between align-items-center py-2 px-3">
                <div><strong>#{$transfer->id}</strong> &middot; {$transfer->remote_user}</div>
                <div class="d-flex align-items-center gap-1">
                    <span class="badge tf-badge">{$transfer->status}</span>
                </div>
            </div>
            <div class="card-body py-2 px-3">
                <div><strong>Host:</strong> {$transfer->remote_host}</div>
                {if $transfer->error_message}
                <div class="text-danger small mt-2 fw-semibold">
                    <i class="fa fa-exclamation-circle me-1"></i>{$transfer->error_message}
                </div>
                {/if}
                
                {assign var="st" value=$transfer->status|lower}
                {assign var="pct" value=$transfer->progress|default:0}
                {if $st === 'completed'}{assign var="pct" value=100}{/if}
                {if $st === 'failed'}{assign var="pct" value=100}{/if}
                
                {assign var="bgClass" value="bg-primary"}
                {assign var="animClass" value=""}
                {if $st === 'running' || $st === 'queued'}
                    {assign var="animClass" value="progress-bar-striped progress-bar-animated"}
                {elseif $st === 'completed'}
                    {assign var="bgClass" value="bg-success"}
                {elseif $st === 'failed'}
                    {assign var="bgClass" value="bg-danger"}
                {/if}
                
                <div class="progress my-2" style="height: 16px; border-radius: .25rem; overflow: hidden; background-color: #e9ecef;">
                    <div class="progress-bar {$animClass} {$bgClass}" role="progressbar" 
                         style="width: {$pct}%; transition: width 0.5s ease; font-size: 10px; font-weight: 700; line-height: 16px; text-align: center; color: #fff;" 
                         aria-valuenow="{$pct}" aria-valuemin="0" aria-valuemax="100">
                        {if $st === 'completed'}100%{elseif $st === 'failed'}Failed{else}{$pct}%{/if}
                    </div>
                </div>
                {if $st === 'running'}
                <div class="small text-dark mb-1 fw-semibold"><i class="fa fa-spinner fa-spin me-1 text-primary"></i>{$transfer->status_message|default:'Working...'}</div>
                {elseif $st === 'completed'}
                <div class="small text-success mb-1 fw-bold"><i class="fa fa-check-circle me-1"></i>Transfer Completed Successfully</div>
                {elseif $st === 'failed'}
                <div class="small text-danger mb-1 fw-bold"><i class="fa fa-times-circle me-1"></i>Transfer Failed</div>
                {elseif $transfer->status_message}
                <div class="small text-dark mb-1 fw-semibold"><i class="fa fa-info-circle me-1 text-primary"></i>{$transfer->status_message}</div>
                {/if}

                <div class="text-muted small mt-1">
                    <div><strong>Started:</strong> {$transfer->started_at}</div>
                    <div><strong>Last checked:</strong> {$transfer->last_checked_at}</div>
                    <div><strong>Completed:</strong> {$transfer->completed_at}</div>
                </div>
            </div>
        </div>
    </div>
    {/foreach}
{else}
    <div class="col-12">
        <div class="alert alert-light text-center mb-0">No transfers found yet.</div>
    </div>
{/if}
</div>

<hr class="my-4">

<div class="card shadow-sm">
    <div class="card-body">
        <h6 class="card-title fw-semibold"><i class="fa fa-info-circle me-1 text-primary"></i> How Transfers Work</h6>
        <ul class="mb-0 small text-muted">
            <li>The transfer uses WHM's built-in remote account migration system.</li>
            <li><strong>cPanel Migration:</strong> Uses the cPanel account credentials over SSH (port 22) to migrate it.</li>
            <li>Status updates automatically every 5 seconds.</li>
            <li>Transfers exceeding 2 hours are automatically marked as Failed.</li>
        </ul>
    </div>
</div>

{literal}
<style>
.tf-card { border-radius:.5rem; border:1px solid #dee2e6; }
.tf-card .card-header { background:#f1f3f5; }
.tf-badge { text-transform:uppercase; font-weight:600; font-size:.75rem; padding:.35em .6em; color:#fff !important; border-radius:.3rem; }
.tf-card[data-status="completed"] { border-left:4px solid #157347; }
.tf-card[data-status="running"]   { border-left:4px solid #0b5ed7; }
.tf-card[data-status="queued"]    { border-left:4px solid #b58100; }
.tf-card[data-status="failed"]    { border-left:4px solid #bb2d3b; }
.tf-card[data-status="unknown"]   { border-left:4px solid #495057; }
.tf-card[data-status="completed"] .tf-badge { background-color:#157347 !important; }
.tf-card[data-status="running"]   .tf-badge { background-color:#0b5ed7 !important; }
.tf-card[data-status="queued"]    .tf-badge { background-color:#b58100 !important; }
.tf-card[data-status="failed"]    .tf-badge { background-color:#bb2d3b !important; }
.tf-card[data-status="unknown"]   .tf-badge { background-color:#495057 !important; }
.form-label { font-weight:500; }
</style>
{/literal}

{*
  IMPORTANT Smarty rules followed here:
  1. nonce="{$cspNonce}"   → on the <script> tag, OUTSIDE {literal}, so Smarty evaluates it.
  2. var serviceID = ...   → OUTSIDE {literal}, so Smarty substitutes the PHP value.
  3. Everything else       → INSIDE {literal}...{/literal} so Smarty ignores JS curly braces.
*}
<script nonce="{$cspNonce}">
var rcServiceID = {$serviceID|default:0};
{literal}
(function () {
    'use strict';

    /* ── Bootstrap form validation ── */
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();

            if (!form.checkValidity()) {
                form.classList.add('was-validated');
                return;
            }

            var btn = form.querySelector('button[type="submit"]');
            if (btn && !form.dataset.submitted) {
                form.dataset.submitted = 'true';
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Starting...';
                
                var formData = new FormData(form);
                fetch(form.action || window.location.href, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        showToast('success', 'Transfer Started', data.message);
                        form.reset();
                        form.classList.remove('was-validated');
                        fetchTransferUpdates();
                    } else {
                        showToast('danger', 'Transfer Error', data.error || 'Failed to start transfer.');
                    }
                })
                .catch(function(err) {
                    showToast('danger', 'Error', 'Network or server error occurred.');
                })
                .finally(function() {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fa fa-play me-1"></i> Start Transfer';
                    delete form.dataset.submitted;
                });
            }
        }, false);
    });

    /* ── Transfer cards live-update ── */
    var cardsWrap = document.getElementById('transfer-cards');
    var serviceID = rcServiceID;

    if (!serviceID || !cardsWrap) return;

    function esc(v)        { return (v != null ? String(v) : ''); }
    function dateOrDash(v) { return v ? esc(v) : '\u2014'; }
    function norm(s)       { return (s || '').toLowerCase(); }

    function makeCard(t) {
        var st   = norm(t.status);
        var errHtml = t.error_message ? '<div class="text-danger small mt-2 fw-semibold"><i class="fa fa-exclamation-circle me-1"></i>' + esc(t.error_message) + '</div>' : '';
        
        var pct = t.progress ? parseInt(t.progress) : 0;
        if (st === 'completed' || st === 'failed') pct = 100;
        
        var bgClass = 'bg-primary';
        var animClass = '';
        if (st === 'running' || st === 'queued') {
            animClass = 'progress-bar-striped progress-bar-animated';
        } else if (st === 'completed') {
            bgClass = 'bg-success';
        } else if (st === 'failed') {
            bgClass = 'bg-danger';
        }
        
        var pctText = pct + '%';
        if (st === 'failed') pctText = 'Failed';
        
        var msg = '';
        if (st === 'running') {
            msg = '<div class="small text-dark mb-1 fw-semibold"><i class="fa fa-spinner fa-spin me-1 text-primary"></i>' + (t.status_message ? esc(t.status_message) : 'Working...') + '</div>';
        } else if (st === 'completed') {
            msg = '<div class="small text-success mb-1 fw-bold"><i class="fa fa-check-circle me-1"></i>Transfer Completed Successfully</div>';
        } else if (st === 'failed') {
            msg = '<div class="small text-danger mb-1 fw-bold"><i class="fa fa-times-circle me-1"></i>Transfer Failed</div>';
        } else if (t.status_message) {
            msg = '<div class="small text-dark mb-1 fw-semibold"><i class="fa fa-info-circle me-1 text-primary"></i>' + esc(t.status_message) + '</div>';
        }
        
        var progressHtml = 
            '<div class="progress my-2" style="height: 16px; border-radius: .25rem; overflow: hidden; background-color: #e9ecef;">' +
                '<div class="progress-bar ' + animClass + ' ' + bgClass + '" role="progressbar" ' +
                     'style="width: ' + pct + '%; transition: width 0.5s ease; font-size: 10px; font-weight: 700; line-height: 16px; text-align: center; color: #fff;" ' +
                     'aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100">' +
                    pctText +
                '</div>' +
            '</div>' + msg;

        var wrap = document.createElement('div');
        wrap.className = 'col-12 col-md-6 col-lg-4';
        wrap.innerHTML =
            '<div class="card h-100 shadow-sm tf-card" data-status="' + st + '">' +
                '<div class="card-header d-flex justify-content-between align-items-center py-2 px-3">' +
                    '<div><strong>#' + esc(t.id) + '</strong> &middot; ' + esc(t.remote_user) + '</div>' +
                    '<div class="d-flex align-items-center gap-1">' +
                        '<span class="badge tf-badge">' + esc(t.status) + '</span>' +
                    '</div>' +
                '</div>' +
                '<div class="card-body py-2 px-3">' +
                    '<div><strong>Host:</strong> ' + esc(t.remote_host) + '</div>' +
                    errHtml +
                    progressHtml +
                    '<div class="text-muted small mt-1">' +
                        '<div><strong>Started:</strong> ' + dateOrDash(t.started_at) + '</div>' +
                        '<div><strong>Last checked:</strong> ' + dateOrDash(t.last_checked_at) + '</div>' +
                        '<div><strong>Completed:</strong> ' + dateOrDash(t.completed_at) + '</div>' +
                    '</div>' +
                '</div>' +
            '</div>';
        return wrap;
    }

    function fetchTransferUpdates() {
        fetch(
            'index.php?m=resellercontrols&page=transfer-updates&id=' + encodeURIComponent(serviceID),
            { credentials: 'same-origin' }
        )
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (data) {
            if (!data || !data.success) return;
            var items = data.transfers || [];
            if (!items.length) {
                cardsWrap.innerHTML = '<div class="col-12"><div class="alert alert-light text-center mb-0">No transfers found yet.</div></div>';
                return;
            }
            items.sort(function (a, b) {
                var da = new Date(a.started_at || 0).getTime();
                var db = new Date(b.started_at || 0).getTime();
                return db !== da ? db - da : Number(b.id) - Number(a.id);
            });
            var frag = document.createDocumentFragment();
            items.forEach(function (t) { frag.appendChild(makeCard(t)); });
            cardsWrap.innerHTML = '';
            cardsWrap.appendChild(frag);
        })
        .catch(function (e) { console.error('Transfer update error:', e); });
    }

    /* ── Simple toast ── */
    function showToast(type, title, message, delayMs) {
        var stack = document.getElementById('rcToastStack');
        if (!stack) {
            stack = document.createElement('div');
            stack.id = 'rcToastStack';
            Object.assign(stack.style, {
                position:'fixed', zIndex:'1080', display:'flex',
                flexDirection:'column', gap:'8px', padding:'8px', pointerEvents:'none'
            });
            document.body.appendChild(stack);
            var place = function () {
                var m = window.matchMedia('(max-width:576px)').matches;
                if (m) {
                    stack.style.top = 'auto'; stack.style.right = '0';
                    stack.style.left = '0'; stack.style.bottom = '12px';
                    stack.style.alignItems = 'center'; stack.style.width = '100%';
                } else {
                    stack.style.top = '12px'; stack.style.right = '12px';
                    stack.style.left = 'auto'; stack.style.bottom = 'auto';
                    stack.style.alignItems = 'flex-end'; stack.style.width = 'auto';
                }
            };
            place();
            window.addEventListener('resize', place);
        }
        var palettes = {
            success: { bg:'#157347', fg:'#fff', border:'#0f5c38' },
            danger:  { bg:'#bb2d3b', fg:'#fff', border:'#8d222c' },
            warning: { bg:'#ffc107', fg:'#1a1a1a', border:'#e0a800' },
            info:    { bg:'#0dcaf0', fg:'#0b1b21', border:'#0aa2c0' }
        };
        var p = palettes[type] || palettes.info;
        var toast = document.createElement('div');
        var mob = window.matchMedia('(max-width:576px)').matches;
        Object.assign(toast.style, {
            background: p.bg, color: p.fg, border: '1px solid ' + p.border,
            boxShadow: '0 10px 24px rgba(0,0,0,.25)', borderRadius: '10px',
            padding: '10px 12px',
            maxWidth: mob ? 'calc(100% - 24px)' : '360px',
            width: mob ? 'calc(100% - 24px)' : 'auto',
            pointerEvents: 'auto', display: 'flex', alignItems: 'center', gap: '10px',
            opacity: '0', transform: 'translateY(-6px)',
            transition: 'opacity .2s ease, transform .2s ease'
        });
        var body = document.createElement('div');
        body.style.flex = '1';
        body.style.wordBreak = 'break-word';
        body.style.lineHeight = '1.35';
        body.innerHTML =
            (title   ? '<strong style="margin-right:6px;">' + String(title)   + '</strong>' : '') +
            (message ? String(message) : '');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.setAttribute('aria-label', 'Close');
        closeBtn.innerHTML = '&times;';
        Object.assign(closeBtn.style, {
            background:'transparent', border:'none', color:p.fg,
            fontSize:'18px', lineHeight:'1', cursor:'pointer', padding:'0 4px', opacity:'.9'
        });
        toast.appendChild(body);
        toast.appendChild(closeBtn);
        stack.appendChild(toast);
        requestAnimationFrame(function () {
            toast.style.opacity = '1';
            toast.style.transform = 'translateY(0)';
        });
        var lifetime = Math.max(1000, Number(delayMs || 3500));
        var hideTimer;
        function dismiss() {
            clearTimeout(hideTimer);
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-6px)';
            setTimeout(function () {
                try { if (toast.parentNode) toast.parentNode.removeChild(toast); } catch (e) {}
            }, 200);
        }
        var start = function () { hideTimer = setTimeout(dismiss, lifetime); };
        var stop  = function () { clearTimeout(hideTimer); };
        toast.addEventListener('mouseenter', stop);
        toast.addEventListener('mouseleave', start);
        closeBtn.addEventListener('click', dismiss);
        start();
    }

    /* ── Confirm modal ── */
    function confirmModal(opts) {
        var o = Object.assign({
            title:       'Clear History',
            message:     '<p>This will permanently remove all completed/failed transfer records.</p><p class="mb-0"><strong>Are you sure?</strong></p>',
            confirmText: 'Yes, clear',
            cancelText:  'Cancel'
        }, opts || {});
        var prev = document.getElementById('rcConfirmModal');
        if (prev && prev.parentNode) prev.parentNode.removeChild(prev);
        var wrapper = document.createElement('div');
        wrapper.innerHTML =
            '<div class="modal fade" id="rcConfirmModal" tabindex="-1" aria-hidden="true">' +
              '<div class="modal-dialog modal-dialog-centered">' +
                '<div class="modal-content">' +
                  '<div class="modal-header"><h5 class="modal-title">' + o.title + '</h5></div>' +
                  '<div class="modal-body">' + o.message + '</div>' +
                  '<div class="modal-footer">' +
                    '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" data-dismiss="modal">' + o.cancelText + '</button>' +
                    '<button type="button" class="btn btn-danger" id="rcConfirmYes">' + o.confirmText + '</button>' +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</div>';
        document.body.appendChild(wrapper.firstChild);
        var modalEl = document.getElementById('rcConfirmModal');
        var yesBtn  = document.getElementById('rcConfirmYes');
        if (window.bootstrap && window.bootstrap.Modal) {
            return new Promise(function (resolve) {
                var bs = new window.bootstrap.Modal(modalEl, { backdrop: 'static' });
                modalEl.addEventListener('hidden.bs.modal', function () { resolve(false); }, { once: true });
                yesBtn.addEventListener('click', function () { resolve(true); bs.hide(); }, { once: true });
                bs.show();
            });
        }
        if (window.jQuery && jQuery(modalEl).modal) {
            return new Promise(function (resolve) {
                jQuery(modalEl).on('hidden.bs.modal', function () { resolve(false); });
                jQuery('#rcConfirmYes').one('click', function () { resolve(true); jQuery(modalEl).modal('hide'); });
                jQuery(modalEl).modal({ backdrop: 'static', keyboard: true, show: true });
            });
        }
        return Promise.resolve(window.confirm(o.title + '\n\n' + o.message.replace(/<[^>]*>/g, '')));
    }

    /* ── Clear history button ── */
    var clearBtn = document.getElementById('clear-history-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            confirmModal().then(function (ok) {
                if (!ok) return;
                clearBtn.disabled = true;
                clearBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Clearing...';
                fetch(
                    'index.php?m=resellercontrols&page=clear-history&id=' + encodeURIComponent(serviceID),
                    { method: 'GET', headers: { 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' }
                )
                .then(function (res) { return res.ok ? res.json() : null; })
                .then(function (data) {
                    if (data && data.success) {
                        var wrap = document.getElementById('transfer-cards');
                        if (wrap) {
                            wrap.innerHTML = '<div class="col-12"><div class="alert alert-light text-center mb-0">No transfers found yet.</div></div>';
                        }
                        showToast('success', 'Clear History', 'Transfer history cleared successfully.');
                    } else {
                        var msg = (data && data.message) ? data.message : 'Unknown error';
                        showToast('danger', 'Clear History', 'Failed to clear: ' + msg, 5000);
                    }
                })
                .catch(function (e) {
                    showToast('danger', 'Clear History', 'Error: ' + e.message, 5000);
                })
                .finally(function () {
                    clearBtn.disabled = false;
                    clearBtn.innerHTML = '<i class="fas fa-trash-alt me-1"></i> Clear History';
                });
            });
        });
    }

    /* ── Start polling ── */
    fetchTransferUpdates();
    setInterval(fetchTransferUpdates, 5000);

})();
{/literal}
</script>
