{* clientarea.tpl — IT FOR NEPAL Reseller Controls *}

{if $error}
<div class="alert alert-danger">
    <i class="fa fa-exclamation-circle me-2"></i>{$error}
</div>
{elseif $message}
<div class="alert alert-info">
    <i class="fa fa-info-circle me-2"></i>{$message}
</div>
{else}

<div class="mb-3">
    <h4 class="fw-bold mb-1">
        <i class="fa fa-cogs me-2 text-primary"></i> Reseller Management Tools
    </h4>
    <p class="text-muted small mb-0">
        Manage cPanel accounts, shell access, DNS zones, and remote migrations from this panel.
        Powered by <strong>Cloud Web Nepal</strong> &mdash; <a href="https://cloudwebnepal.com" target="_blank">cloudwebnepal.com</a>
    </p>
</div>

<div class="row">
    {if isset($controls) && is_array($controls)}
        {foreach from=$controls item=control}
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card shadow-sm h-100 rc-tool-card">
                <div class="card-body text-center d-flex flex-column align-items-center justify-content-center py-4">
                    <div class="rc-icon-wrap mb-3 text-{$control.color}">
                        <i class="fa {$control.icon} fa-3x"></i>
                    </div>
                    <h5 class="fw-semibold mb-2">{$control.title}</h5>
                    <p class="text-muted small mb-3">{$control.description}</p>
                    <a href="{$control.link}" class="btn btn-{$control.color} btn-sm px-4">
                        <i class="fa fa-arrow-right me-1"></i> Open
                    </a>
                </div>
            </div>
        </div>
        {/foreach}
    {/if}
</div>

{literal}
<style>
.rc-tool-card {
    border-radius: .75rem;
    border: 1px solid #dee2e6;
    transition: transform .15s ease, box-shadow .15s ease;
}
.rc-tool-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0,0,0,.1) !important;
}
.rc-icon-wrap {
    width: 72px;
    height: 72px;
    border-radius: 50%;
    background: rgba(13, 110, 253, .06);
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
{/literal}

{/if}
