<?php
/**
 * WHMCS Reseller Controls Addon Module
 * Developed by Cloud Web Nepal
 * Official Website: https://cloudwebnepal.com
 *
 * Supports WHM authentication via:
 *   - Access Hash  (WHM API token / remote access key)
 *   - Username + Password  (Basic HTTP auth fallback)
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

// ---------------------------------------------------------------------------
// MODULE METADATA
// ---------------------------------------------------------------------------

function resellercontrols_config() {
    return [
        'name'        => 'Cloud Web Nepal - Reseller Controls',
        'description' => 'A secure reseller tools module for cPanel/WHM to manage shell access, DNS zones, and transfers.',
        'version'     => '1.2.0',
        'author'      => '<a href="https://cloudwebnepal.com" target="_blank">Cloud Web Nepal</a>',
        'fields'      => [
            'license_key' => [
                'FriendlyName' => 'License Key',
                'Type'         => 'text',
                'Size'         => '50',
                'Description'  => 'Enter your license key obtained from Cloud Web Nepal. Support: +9779845870006.',
                'Default'      => '',
            ],
            'enable_delete_dns' => [
                'FriendlyName' => 'Enable Delete DNS',
                'Type'         => 'yesno',
                'Description'  => 'Tick to enable the Delete DNS Zone feature for clients.',
                'Default'      => 'on',
            ],
            'enable_shell_access' => [
                'FriendlyName' => 'Enable Shell Access',
                'Type'         => 'yesno',
                'Description'  => 'Tick to enable the Shell Access feature for clients.',
                'Default'      => 'on',
            ],
            'enable_transfer_cpanel' => [
                'FriendlyName' => 'Enable Transfer cPanel',
                'Type'         => 'yesno',
                'Description'  => 'Tick to enable the Transfer cPanel Account feature for clients.',
                'Default'      => 'on',
            ]
        ]
    ];
}

// ---------------------------------------------------------------------------
// ACTIVATE / DEACTIVATE
// ---------------------------------------------------------------------------

function resellercontrols_activate() {
    try {
        if (!Capsule::schema()->hasTable('mod_resellercontrols_transfers')) {
            Capsule::schema()->create('mod_resellercontrols_transfers', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->string('remote_host');
                $table->string('remote_user');
                $table->string('status');
                $table->integer('progress')->default(0);
                $table->text('status_message')->nullable();
                $table->text('error_message')->nullable();
                $table->string('auth_type')->default('password')->nullable(); // 'password' or 'accesshash'
                $table->string('session_id')->nullable();
                $table->dateTime('started_at')->nullable();
                $table->dateTime('last_checked_at')->nullable();
                $table->dateTime('completed_at')->nullable();
            });
        } else {
            // Add columns to existing table if missing
            if (!Capsule::schema()->hasColumn('mod_resellercontrols_transfers', 'auth_type')) {
                Capsule::schema()->table('mod_resellercontrols_transfers', function ($table) {
                    $table->string('auth_type')->default('password')->nullable()->after('status');
                });
            }
            if (!Capsule::schema()->hasColumn('mod_resellercontrols_transfers', 'error_message')) {
                Capsule::schema()->table('mod_resellercontrols_transfers', function ($table) {
                    $table->text('error_message')->nullable()->after('status');
                });
            }
            if (!Capsule::schema()->hasColumn('mod_resellercontrols_transfers', 'progress')) {
                Capsule::schema()->table('mod_resellercontrols_transfers', function ($table) {
                    $table->integer('progress')->default(0)->after('status');
                });
            }
            if (!Capsule::schema()->hasColumn('mod_resellercontrols_transfers', 'status_message')) {
                Capsule::schema()->table('mod_resellercontrols_transfers', function ($table) {
                    $table->text('status_message')->nullable()->after('progress');
                });
            }
        }

        // Create table for license cache storage
        if (!Capsule::schema()->hasTable('mod_resellercontrols_license')) {
            Capsule::schema()->create('mod_resellercontrols_license', function ($table) {
                $table->string('setting')->unique();
                $table->text('value')->nullable();
            });
        }

        // Create table for general activity logging (shell access, DNS zone deletion)
        if (!Capsule::schema()->hasTable('mod_resellercontrols_logs')) {
            Capsule::schema()->create('mod_resellercontrols_logs', function ($table) {
                $table->increments('id');
                $table->integer('service_id');
                $table->integer('user_id');
                $table->string('action'); // 'shell_access', 'delete_dns_zone'
                $table->string('target'); // cpanel username or domain
                $table->string('details'); // details text
                $table->string('status'); // 'Success' or 'Failed'
                $table->string('ip_address')->nullable();
                $table->dateTime('created_at');
            });
        }

        // Try checking license immediately upon activation
        resellercontrols_check_license_status(true);

        return [
            'status'      => 'success',
            'description' => 'Module activated successfully. Database tables created/updated.'
        ];
    } catch (\Exception $e) {
        return [
            'status'      => 'error',
            'description' => 'Failed to activate module: ' . $e->getMessage()
        ];
    }
}

function resellercontrols_deactivate() {
    return [
        'status'      => 'success',
        'description' => 'Module deactivated successfully.'
    ];
}

// ---------------------------------------------------------------------------
// ADMIN AREA OUTPUT
// ---------------------------------------------------------------------------

function resellercontrols_output($vars) {
    // -----------------------------------------------------------------------
    // HANDLE POST ACTIONS (Delete / Clear Logs)
    // -----------------------------------------------------------------------
    $actionResponse = '';
    if (isset($_POST['admin_action'])) {
        $action = $_POST['admin_action'];
        
        if ($action === 'clear_transfers') {
            try {
                Capsule::table('mod_resellercontrols_transfers')->truncate();
                $actionResponse = '<div class="alert alert-success"><i class="fa fa-check-circle me-1"></i>All client cPanel transfer history records have been cleared.</div>';
            } catch (\Exception $e) {
                $actionResponse = '<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-1"></i>Error clearing transfers: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
        
        if ($action === 'clear_activity') {
            try {
                Capsule::table('mod_resellercontrols_logs')->truncate();
                $actionResponse = '<div class="alert alert-success"><i class="fa fa-check-circle me-1"></i>All shell access and DNS zone activity logs have been cleared.</div>';
            } catch (\Exception $e) {
                $actionResponse = '<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-1"></i>Error clearing activity logs: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }

        if ($action === 'delete_transfer' && isset($_POST['log_id'])) {
            $logId = (int)$_POST['log_id'];
            try {
                Capsule::table('mod_resellercontrols_transfers')->where('id', $logId)->delete();
                $actionResponse = '<div class="alert alert-success"><i class="fa fa-check-circle me-1"></i>Transfer record #' . $logId . ' deleted.</div>';
            } catch (\Exception $e) {
                $actionResponse = '<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-1"></i>Error deleting record: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }

        if ($action === 'delete_activity' && isset($_POST['log_id'])) {
            $logId = (int)$_POST['log_id'];
            try {
                Capsule::table('mod_resellercontrols_logs')->where('id', $logId)->delete();
                $actionResponse = '<div class="alert alert-success"><i class="fa fa-check-circle me-1"></i>Activity log #' . $logId . ' deleted.</div>';
            } catch (\Exception $e) {
                $actionResponse = '<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-1"></i>Error deleting log: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
    }

    // Check current license status
    $license = resellercontrols_check_license_status();
    $licenseStatusHtml = '';
    
    // Extract expiry if available in the message
    $expiryStr = '';
    if (preg_match('/\(Expiry:\s*([^\)]+)\)/i', $license['message'], $matches)) {
        $expiryStr = ' (Expires: ' . trim($matches[1]) . ')';
    }

    if ($license['status'] === 'active') {
        $licenseStatusHtml = '<span style="background: #198754; color: #fff; font-size: 14px; font-weight: 600; padding: 6px 12px; border-radius: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"><i class="fa fa-check-circle" style="margin-right: 4px;"></i> License Active' . htmlspecialchars($expiryStr) . '</span>';
    } else {
        $licenseStatusHtml = '<span style="background: #dc3545; color: #fff; font-size: 14px; font-weight: 600; padding: 6px 12px; border-radius: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"><i class="fa fa-times-circle" style="margin-right: 4px;"></i> License Invalid: ' . htmlspecialchars($license['message']) . '</span>';
    }

    // Fetch Transfers
    $transfers = Capsule::table('mod_resellercontrols_transfers')
        ->orderBy('id', 'desc')
        ->limit(100)
        ->get();

    // Fetch Activity Logs (Shell & DNS)
    $activities = [];
    if (Capsule::schema()->hasTable('mod_resellercontrols_logs')) {
        $activities = Capsule::table('mod_resellercontrols_logs')
            ->orderBy('id', 'desc')
            ->limit(100)
            ->get();
    }

    // Build Transfers Table HTML
    $transfersHtml = '';
    if (count($transfers) > 0) {
        $transfersHtml .= '
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 style="margin:0;font-weight:600;"><i class="fa fa-file-import text-muted me-2"></i>cPanel Migration Logs</h4>
            <form method="post" action="" onsubmit="return confirm(\'Are you sure you want to delete ALL cPanel transfer records? This cannot be undone.\');">
                <input type="hidden" name="admin_action" value="clear_transfers">
                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash-alt me-1"></i>Clear All Transfer Records</button>
            </form>
        </div>
        <table class="table table-bordered table-striped" style="background:#fff;width:100%;text-align:left;">
            <thead style="background:#e9ecef;">
                <tr>
                    <th style="padding:10px;">ID</th>
                    <th style="padding:10px;">Service ID</th>
                    <th style="padding:10px;">Remote Host</th>
                    <th style="padding:10px;">cPanel User</th>
                    <th style="padding:10px;">Status</th>
                    <th style="padding:10px;">Started At</th>
                    <th style="padding:10px;text-align:center;">Action</th>
                </tr>
            </thead>
            <tbody>';
        foreach ($transfers as $t) {
            $statusColor = ($t->status === 'Completed') ? '#198754' : (($t->status === 'Failed') ? '#dc3545' : '#fd7e14');
            $transfersHtml .= '<tr>
                <td style="padding:10px;">' . (int)$t->id . '</td>
                <td style="padding:10px;"><a href="clientsservices.php?id=' . (int)$t->service_id . '" target="_blank">Service #' . (int)$t->service_id . '</a></td>
                <td style="padding:10px;">' . htmlspecialchars($t->remote_host) . '</td>
                <td style="padding:10px;">' . htmlspecialchars($t->remote_user) . '</td>
                <td style="padding:10px;color:' . $statusColor . ';font-weight:600;">
                    ' . htmlspecialchars($t->status) . '
                    ' . (!empty($t->error_message) ? '<br><small class="text-danger" style="font-weight:500;">Error: ' . htmlspecialchars($t->error_message) . '</small>' : '') . '
                </td>
                <td style="padding:10px;">' . htmlspecialchars($t->started_at) . '</td>
                <td style="padding:10px;text-align:center;">
                    <form method="post" action="" style="margin:0;" onsubmit="return confirm(\'Delete this transfer log?\');">
                        <input type="hidden" name="admin_action" value="delete_transfer">
                        <input type="hidden" name="log_id" value="' . (int)$t->id . '">
                        <button type="submit" class="btn btn-xs btn-default text-danger" style="padding:2px 6px;"><i class="fa fa-times"></i></button>
                    </form>
                </td>
            </tr>';
        }
        $transfersHtml .= '</tbody></table>';
    } else {
        $transfersHtml .= '<div class="alert alert-light text-center py-4">No cPanel transfers have been logged yet.</div>';
    }

    // Build Activity Logs (Shell & DNS) HTML
    $activitiesHtml = '';
    if (count($activities) > 0) {
        $activitiesHtml .= '
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 style="margin:0;font-weight:600;"><i class="fa fa-terminal text-muted me-2"></i>Shell &amp; DNS Change Logs</h4>
            <form method="post" action="" onsubmit="return confirm(\'Are you sure you want to delete ALL activity logs? This cannot be undone.\');">
                <input type="hidden" name="admin_action" value="clear_activity">
                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash-alt me-1"></i>Clear All Activity Logs</button>
            </form>
        </div>
        <table class="table table-bordered table-striped" style="background:#fff;width:100%;text-align:left;">
            <thead style="background:#e9ecef;">
                <tr>
                    <th style="padding:10px;">ID</th>
                    <th style="padding:10px;">Service ID</th>
                    <th style="padding:10px;">Action</th>
                    <th style="padding:10px;">Target</th>
                    <th style="padding:10px;">Details</th>
                    <th style="padding:10px;">Status</th>
                    <th style="padding:10px;">IP Address</th>
                    <th style="padding:10px;">Date &amp; Time</th>
                    <th style="padding:10px;text-align:center;">Action</th>
                </tr>
            </thead>
            <tbody>';
        foreach ($activities as $act) {
            $actLabel = ($act->action === 'shell_access') ? '<span class="label label-info"><i class="fa fa-terminal me-1"></i>Shell</span>' : '<span class="label label-warning"><i class="fa fa-globe me-1"></i>DNS Zone</span>';
            $statusColor = ($act->status === 'Success') ? '#198754' : '#dc3545';
            
            $activitiesHtml .= '<tr>
                <td style="padding:10px;">' . (int)$act->id . '</td>
                <td style="padding:10px;"><a href="clientsservices.php?id=' . (int)$act->service_id . '" target="_blank">Service #' . (int)$act->service_id . '</a></td>
                <td style="padding:10px;">' . $actLabel . '</td>
                <td style="padding:10px;"><code>' . htmlspecialchars($act->target) . '</code></td>
                <td style="padding:10px;">' . htmlspecialchars($act->details) . '</td>
                <td style="padding:10px;color:' . $statusColor . ';font-weight:600;">' . htmlspecialchars($act->status) . '</td>
                <td style="padding:10px;">' . htmlspecialchars($act->ip_address) . '</td>
                <td style="padding:10px;">' . htmlspecialchars($act->created_at) . '</td>
                <td style="padding:10px;text-align:center;">
                    <form method="post" action="" style="margin:0;" onsubmit="return confirm(\'Delete this activity log?\');">
                        <input type="hidden" name="admin_action" value="delete_activity">
                        <input type="hidden" name="log_id" value="' . (int)$act->id . '">
                        <button type="submit" class="btn btn-xs btn-default text-danger" style="padding:2px 6px;"><i class="fa fa-times"></i></button>
                    </form>
                </td>
            </tr>';
        }
        $activitiesHtml .= '</tbody></table>';
    } else {
        $activitiesHtml .= '<div class="alert alert-light text-center py-4">No shell access or DNS zone operations have been logged yet.</div>';
    }

    // Active tab detection
    $activeTab = isset($_POST['admin_action']) && strpos($_POST['admin_action'], 'activity') !== false ? 'activity' : (isset($_POST['admin_action']) && strpos($_POST['admin_action'], 'transfer') !== false ? 'transfers' : 'overview');

    $features = [];
    if (!isset($vars['enable_transfer_cpanel']) || $vars['enable_transfer_cpanel'] === 'on') $features[] = 'cPanel Transfers';
    if (!isset($vars['enable_shell_access']) || $vars['enable_shell_access'] === 'on') $features[] = 'Shell Access Management';
    if (!isset($vars['enable_delete_dns']) || $vars['enable_delete_dns'] === 'on') $features[] = 'DNS Zone Deletion';
    $featuresText = count($features) > 0 ? implode(', ', $features) : '<span style="color:#dc3545;">None (All disabled)</span>';

    echo '
    <div style="font-family:\'Outfit\',\'Inter\',sans-serif;margin-bottom:20px;">
        ' . $actionResponse . '
        
        <div style="background:#f8f9fa;border:1px solid #dee2e6;border-radius:8px;padding:30px;box-shadow:0 4px 6px rgba(0,0,0,0.05);">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:25px;">
                <h1 style="color:#0d6efd;font-weight:700;margin:0;">Cloud Web Nepal</h1>
                ' . $licenseStatusHtml . '
            </div>
            
            <p style="font-size:16px;color:#495057;line-height:1.6;margin-bottom:25px;">
                Thank you for using the <strong>Cloud Web Nepal</strong> Reseller Controls module. This addon allows your reseller hosting clients to manage SSH Jailshell access, delete DNS zones, and migrate remote cPanel accounts directly from the WHMCS client area.
            </p>
            
            <!-- Bootstrap Tabs Navigation -->
            <ul class="nav nav-tabs" style="margin-bottom:20px;">
                <li class="active"><a data-toggle="tab" href="#overview" style="font-weight:600;"><i class="fa fa-info-circle me-1"></i>Overview</a></li>
                <li><a data-toggle="tab" href="#transfers-tab" style="font-weight:600;"><i class="fa fa-file-import me-1"></i>cPanel Migration Logs</a></li>
                <li><a data-toggle="tab" href="#activity-tab" style="font-weight:600;"><i class="fa fa-terminal me-1"></i>Activity logs</a></li>
            </ul>
            
            <div class="tab-content" style="background:#fff;border:1px solid #dee2e6;border-top:none;padding:25px;border-radius:0 0 8px 8px;">
                <!-- Tab 1: Overview -->
                <div id="overview" class="tab-pane fade in active">
                    <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px 16px;margin-bottom:25px;">
                        <strong>WHM Authentication:</strong> The module connects to WHM port 2087 using either an <em>Access Hash / API Token</em> (preferred) or <em>Username + Password</em> (fallback). Configure these under <strong>Setup &rarr; Servers</strong> for each server.
                    </div>
                    <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px 16px;margin-bottom:25px;">
                        <strong>Feature Toggles:</strong> You can enable or disable specific features (Shell Access, DNS Deletion, cPanel Transfers) by going to <strong>System Settings &rarr; Addon Modules</strong> (or Setup &rarr; Addon Modules) and configuring this module.
                    </div>
                    
                    <h3 style="font-weight:600;color:#212529;margin-bottom:15px;border-bottom:1px solid #f1f1f1;padding-bottom:8px;">Module Support &amp; Resources</h3>

                    
                    <table class="table" style="max-width:700px;margin-bottom:0;">
                        <tbody>
                            <tr><td style="font-weight:600;width:220px;border-top:none;">Official Website:</td><td style="border-top:none;"><a href="https://cloudwebnepal.com" target="_blank" style="color:#0d6efd;text-decoration:none;font-weight:500;">https://cloudwebnepal.com</a></td></tr>
                            <tr><td style="font-weight:600;">License Status:</td><td>' . ($license['status'] === 'active' ? '<span style="color:#198754;font-weight:600;">Active' . htmlspecialchars($expiryStr) . '</span>' : '<span style="color:#dc3545;font-weight:600;">Invalid (' . htmlspecialchars($license['message']) . ')</span>') . '</td></tr>
                            <tr><td style="font-weight:600;">Author:</td><td>Cloud Web Nepal</td></tr>
                            <tr><td style="font-weight:600;">Support Hotline:</td><td><strong>+9779845870006</strong></td></tr>
                            <tr><td style="font-weight:600;">WHM Auth Modes:</td><td>Access Hash (token), Username + Password</td></tr>
                            <tr><td style="font-weight:600;">Features Enabled:</td><td>' . $featuresText . '</td></tr>
                        </tbody>
                    </table>
                </div>
                
                <!-- Tab 2: cPanel Migration Logs -->
                <div id="transfers-tab" class="tab-pane fade">
                    ' . $transfersHtml . '
                </div>
                
                <!-- Tab 3: Shell & DNS Activity Logs -->
                <div id="activity-tab" class="tab-pane fade">
                    ' . $activitiesHtml . '
                </div>
            </div>
        </div>
    </div>
    
    <!-- Retain active tab on form submission -->
    <script>
    jQuery(document).ready(function() {
        var active = "' . $activeTab . '";
        if (active === "transfers") {
            jQuery(\'ul.nav-tabs a[href="#transfers-tab"]\').tab(\'show\');
        } else if (active === "activity") {
            jQuery(\'ul.nav-tabs a[href="#activity-tab"]\').tab(\'show\');
        }
    });
    </script>';
}

// ---------------------------------------------------------------------------
// WHM API HELPERS
// ---------------------------------------------------------------------------

/**
 * Extract and decrypt server credentials from a joined tblhosting/tblservers row.
 *
 * Returns an array with keys: ip, username, password, accesshash
 */
function resellercontrols_get_server_credentials($service) {
    $ip          = !empty($service->ipaddress) ? $service->ipaddress : $service->hostname;
    $username    = $service->serverusername;

    // Decrypt the stored password using the WHMCS global decrypt helper
    $password    = '';
    if (!empty($service->serverpassword)) {
        try {
            $password = \decrypt($service->serverpassword);
        } catch (\Exception $e) {
            $password = '';
        }
    }

    // Clean the access hash: remove all whitespace and newlines
    $accesshash  = '';
    if (!empty($service->accesshash)) {
        $accesshash = preg_replace('/\s+/', '', $service->accesshash);
    }

    return [
        'ip'         => $ip,
        'username'   => $username,
        'password'   => $password,
        'accesshash' => $accesshash,
    ];
}

/**
 * Make a WHM JSON API call.
 *
 * Authentication priority:
 *   1. Access Hash (WHM API token / remote access key) — if $serverAccessHash is non-empty
 *   2. Username + Password (HTTP Basic) — fallback
 *
 * @param string $serverIp         WHM server IP or hostname
 * @param string $serverUsername   WHM root or reseller username
 * @param string $serverPassword   Plain-text password (decrypted)
 * @param string $serverAccessHash Clean access hash / API token (no whitespace)
 * @param string $action           WHM API function name (e.g. 'accountsummary')
 * @param array  $params           Additional query parameters
 * @param int    $timeout          cURL timeout in seconds (default 30)
 *
 * @return array  Decoded JSON response, or ['error' => '...'] on failure
 */
function resellercontrols_call_whm_api($serverIp, $serverUsername, $serverPassword, $serverAccessHash, $action, $params = [], $timeout = 30) {
    // Build URL
    $url = "https://{$serverIp}:2087/json-api/{$action}?" . http_build_query(array_merge(['api.version' => 1], $params));

    // Determine auth header
    $authHeader = '';
    if (!empty($serverAccessHash)) {
        // WHM API token / access hash authentication
        $authHeader = "Authorization: WHM {$serverUsername}:{$serverAccessHash}";
    } elseif (!empty($serverPassword)) {
        // HTTP Basic authentication (username:password)
        $authHeader = "Authorization: Basic " . base64_encode("{$serverUsername}:{$serverPassword}");
    } else {
        return ['error' => 'No authentication credentials provided. Configure the server access hash or password in WHMCS.'];
    }

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_HTTPHEADER     => [$authHeader, 'Accept: application/json'],
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['error' => "WHM connection error: {$error}"];
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 401 || $httpCode === 403) {
        return ['error' => "WHM authentication failed (HTTP {$httpCode}). Check your access hash or password."];
    }

    if (empty($response)) {
        return ['error' => 'Empty response from WHM server.'];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return ['error' => 'Invalid JSON response from WHM: ' . substr($response, 0, 300)];
    }

    return $data;
}

/**
 * Resolve the WHM API result status from a response array.
 * Handles both legacy (metadata.result) and newer (result) response shapes.
 *
 * Returns true on success, false on failure.
 */
function resellercontrols_whm_result_ok($response) {
    if (isset($response['metadata']['result'])) {
        return $response['metadata']['result'] == 1;
    }
    if (isset($response['result'])) {
        return $response['result'] == 1;
    }
    return false;
}

/**
 * Extract a human-readable reason/message from a WHM response.
 */
function resellercontrols_whm_reason($response, $default = 'Unknown error occurred.') {
    if (isset($response['metadata']['reason']) && !empty($response['metadata']['reason'])) {
        return $response['metadata']['reason'];
    }
    if (isset($response['reason']) && !empty($response['reason'])) {
        return $response['reason'];
    }
    if (isset($response['error']) && !empty($response['error'])) {
        return $response['error'];
    }
    return $default;
}

/**
 * Parse the state of a transfer session from the WHM response.
 * Returns one of: 'Completed', 'Failed', 'Running', '' (unknown)
 */
function resellercontrols_parse_transfer_state($whmStatus) {
    // Try data.state (common path)
    $state = '';
    if (isset($whmStatus['data']['state'])) {
        $state = strtoupper($whmStatus['data']['state']);
    } elseif (isset($whmStatus['data']['transfer_session']['state'])) {
        $state = strtoupper($whmStatus['data']['transfer_session']['state']);
    } elseif (isset($whmStatus['metadata']['state'])) {
        $state = strtoupper($whmStatus['metadata']['state']);
    }

    if (empty($state)) return '';

    if (strpos($state, 'COMPLETE') !== false || strpos($state, 'RESTORED') !== false || strpos($state, 'SUCCESS') !== false) {
        return 'Completed';
    }
    if (strpos($state, 'FAIL') !== false || strpos($state, 'ERROR') !== false || strpos($state, 'ABORT') !== false) {
        return 'Failed';
    }
    if (strpos($state, 'PROGRESS') !== false || strpos($state, 'RUNNING') !== false || strpos($state, 'ACTIVE') !== false) {
        return 'Running';
    }

    return '';
}

/**
 * Check if an account exists via WHM accountsummary API.
 * Returns true if found, false otherwise.
 */
function resellercontrols_account_exists($serverIp, $serverUsername, $serverPassword, $serverAccessHash, $cpuser) {
    $r = resellercontrols_call_whm_api($serverIp, $serverUsername, $serverPassword, $serverAccessHash, 'accountsummary', ['user' => $cpuser]);
    // WHM v1 wraps in data.acct[] or directly in acct[]
    if (isset($r['data']['acct'][0]['user'])) return true;
    if (isset($r['acct'][0]['user']))           return true;
    return false;
}

/**
 * Get account owner from WHM accountsummary.
 * Returns the owner username string, or '' if not found.
 */
function resellercontrols_account_owner($serverIp, $serverUsername, $serverPassword, $serverAccessHash, $cpuser) {
    $r = resellercontrols_call_whm_api($serverIp, $serverUsername, $serverPassword, $serverAccessHash, 'accountsummary', ['user' => $cpuser]);
    if (isset($r['data']['acct'][0]['owner'])) return $r['data']['acct'][0]['owner'];
    if (isset($r['acct'][0]['owner']))          return $r['acct'][0]['owner'];
    return '';
}

/**
 * Get a configuration value of the addon module from WHMCS settings
 */
if (!function_exists('resellercontrols_get_config_value')) {
    function resellercontrols_get_config_value($settingName) {
        try {
            $val = Capsule::table('tbladdonmodules')
                ->where('module', 'resellercontrols')
                ->where('setting', $settingName)
                ->value('value');
            return $val ?: '';
        } catch (\Exception $e) {
            return '';
        }
    }
}

/**
 * Retrieve cached license info from local DB table
 */
if (!function_exists('resellercontrols_get_license_cache')) {
    function resellercontrols_get_license_cache($setting) {
        try {
            if (Capsule::schema()->hasTable('mod_resellercontrols_license')) {
                return Capsule::table('mod_resellercontrols_license')
                    ->where('setting', $setting)
                    ->value('value') ?: '';
            }
        } catch (\Exception $e) {
            // ignore
        }
        return '';
    }
}

/**
 * Save license details to the local DB cache
 */
if (!function_exists('resellercontrols_set_license_cache')) {
    function resellercontrols_set_license_cache($setting, $value) {
        try {
            if (Capsule::schema()->hasTable('mod_resellercontrols_license')) {
                Capsule::table('mod_resellercontrols_license')->updateOrInsert(
                    ['setting' => $setting],
                    ['value' => $value]
                );
            }
        } catch (\Exception $e) {
            // ignore
        }
    }
}

/**
 * Log activity for reseller controls operations
 */
if (!function_exists('resellercontrols_log_action')) {
    function resellercontrols_log_action($serviceId, $userId, $action, $target, $details, $status) {
        try {
            $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
            Capsule::table('mod_resellercontrols_logs')->insert([
                'service_id' => (int)$serviceId,
                'user_id'    => (int)$userId,
                'action'     => (string)$action,
                'target'     => (string)$target,
                'details'    => (string)$details,
                'status'     => (string)$status,
                'ip_address' => $ip,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            // ignore
        }
    }
}

/**
 * Validate license key from cloudwebnepal.com/api2 and manage local caching (12-hour expiry)
 * Checks outgoing server IP and current server domain.
 *
 * @param bool $force Force API call bypassing cache
 * @return array
 */
if (!function_exists('resellercontrols_check_license_status')) {
    function resellercontrols_check_license_status($force = false) {
        $licenseKey = resellercontrols_get_config_value('license_key');
        if (empty($licenseKey)) {
            return [
                'status'  => 'invalid',
                'message' => 'License key is empty. Please enter your Reseller Controls license key under WHMCS Addon Settings.'
            ];
        }

        $lastCheck     = (int)resellercontrols_get_license_cache('last_check');
        $cachedStatus  = resellercontrols_get_license_cache('status');
        $cachedMessage = resellercontrols_get_license_cache('message');
        $cachedKey     = resellercontrols_get_license_cache('cached_key');

        // Automatically bypass the 12-hour cache if the license key has changed
        if ($licenseKey !== $cachedKey) {
            $force = true;
        }

        // 12 hours local caching to keep client area fast
        if (!$force && $cachedStatus && (time() - $lastCheck < 43200)) {
            return [
                'status'  => $cachedStatus,
                'message' => $cachedMessage
            ];
        }

        // Determine outgoing server IP (using api.ipify.org check as primary, fallback to server var)
        $ip = '';
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://api.ipify.org');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $ip = curl_exec($ch);
            curl_close($ch);
            if ($ip) {
                $ip = trim($ip);
            }
        }
        if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
            $ip = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : (isset($_SERVER['LOCAL_ADDR']) ? $_SERVER['LOCAL_ADDR'] : '127.0.0.1');
        }

        // Determine domain (cleaned SystemURL if available, otherwise SERVER_NAME)
        $domain = '';
        if (class_exists('\WHMCS\Config\Setting')) {
            $domain = \WHMCS\Config\Setting::getValue('SystemURL');
        }
        if (empty($domain)) {
            $domain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '');
        }
        $domain = preg_replace('/^https?:\/\//i', '', $domain);
        $domain = preg_replace('/:\d+$/', '', $domain);
        $parsedHost = parse_url('http://' . $domain, PHP_URL_HOST);
        if ($parsedHost) {
            $domain = $parsedHost;
        }
        $domain = trim($domain);

        // Call Cloud Web Nepal licensing server API directly via index.php to bypass redirects
        $apiUrl = 'https://cloudwebnepal.com/api2/index.php';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'licensekey' => $licenseKey,
            'domain'     => $domain,
            'ip'         => $ip
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Offline / connection error fallback: allow cache for up to 3 days
        if ($httpCode !== 200 || empty($response)) {
            if ($cachedStatus && (time() - $lastCheck < 259200)) {
                return [
                    'status'  => $cachedStatus,
                    'message' => $cachedMessage
                ];
            }
            return [
                'status'  => 'error',
                'message' => 'Unable to verify license: License server unreachable.'
            ];
        }

        $result = json_decode($response, true);
        if (!is_array($result)) {
            $cleanResponse = trim(strtolower($response));
            if ($cleanResponse === 'active' || $cleanResponse === 'valid' || $cleanResponse === 'success' || strpos($cleanResponse, 'active') !== false || strpos($cleanResponse, 'valid') !== false) {
                $result = ['status' => 'active', 'message' => 'License is active and valid.'];
            } else {
                $result = ['status' => 'invalid', 'message' => 'License status check failed: Invalid response.'];
            }
        }

        $status  = 'invalid';
        $message = isset($result['message']) ? $result['message'] : 'License key is invalid or unauthorized.';

        if (isset($result['status'])) {
            $resStatus = strtolower($result['status']);
            if ($resStatus === 'active' || $resStatus === 'valid' || $resStatus === 'success') {
                $status = 'active';
            }
        }

        if (isset($result['expires']) && !empty($result['expires'])) {
            $message .= ' (Expiry: ' . $result['expires'] . ')';
        }

        // Update local cache
        resellercontrols_set_license_cache('status', $status);
        resellercontrols_set_license_cache('message', $message);
        resellercontrols_set_license_cache('cached_key', $licenseKey);
        resellercontrols_set_license_cache('last_check', time());

        return [
            'status'  => $status,
            'message' => $message
        ];
    }
}

// ---------------------------------------------------------------------------
// CSRF TOKEN
// ---------------------------------------------------------------------------

function resellercontrols_check_token() {
    $postedToken = isset($_POST['token']) ? $_POST['token'] : '';
    if (empty($postedToken)) return false;

    // WHMCS stores the client-area CSRF token in the session under 'token' (not 'tk').
    // We also check the WHMCS global $token variable as a fallback.
    $sessionToken = '';
    if (class_exists('\WHMCS\Session')) {
        $sessionToken = \WHMCS\Session::get('token');
    }
    if (empty($sessionToken) && isset($_SESSION['token'])) {
        $sessionToken = $_SESSION['token'];
    }
    // Last fallback: WHMCS global $token variable (available in all client area contexts)
    if (empty($sessionToken)) {
        global $token;
        $sessionToken = isset($token) ? $token : '';
    }

    return (!empty($sessionToken) && hash_equals((string)$sessionToken, (string)$postedToken));
}

function resellercontrols_get_csrf_token() {
    // WHMCS automatically injects {$token} into all client area Smarty templates.
    // This getter is a convenience for other PHP contexts.
    if (class_exists('\WHMCS\Session')) {
        $t = \WHMCS\Session::get('token');
        if (!empty($t)) return $t;
    }
    if (isset($_SESSION['token'])) return $_SESSION['token'];
    global $token;
    return isset($token) ? $token : '';
}

// ---------------------------------------------------------------------------
// CLIENT AREA
// ---------------------------------------------------------------------------

function resellercontrols_clientarea($vars) {
    // 1. Verify license status
    $license = resellercontrols_check_license_status();
    if ($license['status'] !== 'active') {
        return [
            'templatefile' => 'templates/clientarea',
            'vars'         => [
                'error' => '<strong>License Error:</strong> ' . htmlspecialchars($license['message']) . '<br>Please enter a valid license under settings or contact Cloud Web Nepal support at <strong>+9779845870006</strong> / <a href="https://cloudwebnepal.com" target="_blank">cloudwebnepal.com</a>.'
            ]
        ];
    }

    $userid = \WHMCS\Session::get('uid');
    if (!$userid) {
        return [
            'templatefile' => 'templates/clientarea',
            'vars'         => ['error' => 'You must be logged in to view this page.']
        ];
    }

    $serviceID = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
    if (!$serviceID) {
        return [
            'templatefile' => 'templates/clientarea',
            'vars'         => ['error' => 'No service selected. Please select a reseller hosting service.']
        ];
    }

    // Retrieve service + parent server credentials + product type in one query
    $service = Capsule::table('tblhosting')
        ->join('tblservers', 'tblhosting.server', '=', 'tblservers.id')
        ->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')
        ->select(
            'tblhosting.*',
            'tblservers.ipaddress',
            'tblservers.hostname',
            'tblservers.username as serverusername',
            'tblservers.password as serverpassword',
            'tblservers.accesshash',
            'tblproducts.type as producttype'
        )
        ->where('tblhosting.id', $serviceID)
        ->where('tblhosting.userid', $userid)
        ->where('tblhosting.domainstatus', 'Active')
        ->first();

    if (!$service || $service->producttype !== 'reselleraccount') {
        return [
            'templatefile' => 'templates/clientarea',
            'vars'         => ['error' => 'Invalid, inactive, or unauthorized service. This panel is only available for active reseller hosting services.']
        ];
    }

    // Extract credentials
    $creds         = resellercontrols_get_server_credentials($service);
    $serverIp      = $creds['ip'];
    $serverUsername = $creds['username'];
    $serverPassword = $creds['password'];
    $serverAccessHash = $creds['accesshash'];

    // CSRF token for forms
    $csrfToken = resellercontrols_get_csrf_token();

    $page     = isset($_GET['page']) ? $_GET['page'] : '';
    $response = ['success' => '', 'error' => ''];

    // -----------------------------------------------------------------------
    // AJAX: Clear transfer history
    // -----------------------------------------------------------------------
    if ($page === 'clear-history') {
        Capsule::table('mod_resellercontrols_transfers')
            ->where('service_id', $serviceID)
            ->whereIn('status', ['Completed', 'Failed', 'Unknown'])
            ->delete();

        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }

    // -----------------------------------------------------------------------
    // AJAX: Poll transfer status updates
    // -----------------------------------------------------------------------
    if ($page === 'transfer-updates') {
        $transfers = Capsule::table('mod_resellercontrols_transfers')
            ->where('service_id', $serviceID)
            ->orderBy('id', 'desc')
            ->get();

        foreach ($transfers as $t) {
            if (!in_array($t->status, ['Running', 'Queued'])) {
                continue;
            }

            $newState = '';
            $whmError = '';

            // 1. Ask WHM for transfer session state
            if (!empty($t->session_id)) {
                $whmStatus = resellercontrols_call_whm_api(
                    $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                    'get_transfer_session_state',
                    ['transfer_session_id' => $t->session_id],
                    15
                );

                if (!isset($whmStatus['error'])) {
                    $newState = resellercontrols_parse_transfer_state($whmStatus);
                    
                    // Extract progress and status message from transfer_items list
                    $progressVal = 0;
                    $statusMsg   = '';
                    
                    $itemsList = [];
                    if (isset($whmStatus['data']['transfer_session']['transfer_items'])) {
                        $itemsList = $whmStatus['data']['transfer_session']['transfer_items'];
                    } elseif (isset($whmStatus['data']['transfer_items'])) {
                        $itemsList = $whmStatus['data']['transfer_items'];
                    }
                    
                    foreach ($itemsList as $item) {
                        if (
                            (isset($item['target']) && strtolower($item['target']) === strtolower($t->remote_user)) || 
                            (isset($item['user']) && strtolower($item['user']) === strtolower($t->remote_user))
                        ) {
                            if (isset($item['progress'])) {
                                $progressVal = (int)$item['progress'];
                            }
                            if (isset($item['status'])) {
                                $statusMsg = $item['status'];
                            } elseif (isset($item['state'])) {
                                $statusMsg = $item['state'];
                            }
                            
                            // If the item itself failed, mark the whole transfer as failed
                            if (in_array(strtolower($statusMsg), ['failed', 'aborted', 'error', 'timeout'])) {
                                $newState = 'Failed';
                                $whmError = 'Item transfer failed: ' . $statusMsg;
                            }
                            break;
                        }
                    }
                    
                    // Extract warning or failure message from WHM
                    if (isset($whmStatus['data']['transfer_session']['error'])) {
                        $whmError = $whmStatus['data']['transfer_session']['error'];
                    } elseif (isset($whmStatus['data']['error'])) {
                        $whmError = $whmStatus['data']['error'];
                    }
                } else {
                    $whmError = $whmStatus['error'];
                }
            }

            // 2. Fallback: check if the account now exists locally
            if (!$newState || $newState === 'Running') {
                if (resellercontrols_account_exists($serverIp, $serverUsername, $serverPassword, $serverAccessHash, $t->remote_user)) {
                    $newState = 'Completed';
                }
            }

            // 3. Timeout guard: 2 hours
            if ((!$newState || $newState === 'Running') && (time() - strtotime($t->started_at) > 7200)) {
                $newState = 'Failed';
                if (empty($whmError)) {
                    $whmError = 'Transfer session timed out (exceeded 2 hours limit).';
                }
            }

            if ($newState === 'Completed') {
                $progressVal = 100;
                $statusMsg = 'Completed';
            }

            $update = [
                'last_checked_at' => date('Y-m-d H:i:s'),
                'progress'        => $progressVal,
                'status_message'  => $statusMsg,
            ];
            
            if (!empty($whmError)) {
                $update['error_message'] = $whmError;
                // If there's an error and state is not active/running/completed, treat it as Failed
                if ($newState !== 'Completed' && (strpos(strtolower($whmError), 'fail') !== false || strpos(strtolower($whmError), 'error') !== false || strpos(strtolower($whmError), 'connection') !== false)) {
                    $newState = 'Failed';
                }
            }

            if ($newState && $newState !== $t->status) {
                $update['status'] = $newState;
                if (in_array($newState, ['Completed', 'Failed'])) {
                    $update['completed_at'] = date('Y-m-d H:i:s');
                }
                $t->status = $newState;
            }

            Capsule::table('mod_resellercontrols_transfers')->where('id', $t->id)->update($update);
        }

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'transfers' => $transfers]);
        exit;
    }

    // -----------------------------------------------------------------------
    // 1. DELETE DNS ZONE
    // -----------------------------------------------------------------------
    if ($page === 'delete-dns-zone') {
        if (isset($vars['enable_delete_dns']) && $vars['enable_delete_dns'] !== 'on') {
            return [
                'templatefile' => 'templates/clientarea',
                'vars'         => ['error' => 'The Delete DNS feature has been disabled by the administrator.']
            ];
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!resellercontrols_check_token()) {
                $response['error'] = 'Invalid CSRF token. Please reload the page and try again.';
            } else {
                $domain = trim(strtolower($_POST['domain']));

                if (empty($domain) || !preg_match('/^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z]{2,})+$/i', $domain)) {
                    $response['error'] = 'Please enter a valid domain name (e.g. example.com).';
                } else {
                    // Security: ensure client has ever owned this domain in WHMCS
                    $owned = Capsule::table('tblhosting')->where('userid', $userid)->where('domain', $domain)->exists()
                          || Capsule::table('tbldomains')->where('userid', $userid)->where('domain', $domain)->exists();

                    if (!$owned) {
                        $response['error'] = 'Access denied: This domain is not associated with your account.';
                    } else {
                        $whmResponse = resellercontrols_call_whm_api(
                            $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                            'killdns',
                            ['domain' => $domain]
                        );

                        if (isset($whmResponse['error'])) {
                            $response['error'] = $whmResponse['error'];
                            resellercontrols_log_action($serviceID, $userid, 'delete_dns_zone', $domain, 'Connection error: ' . $whmResponse['error'], 'Failed');
                        } elseif (resellercontrols_whm_result_ok($whmResponse)) {
                            $response['success'] = "DNS zone for <strong>" . htmlspecialchars($domain) . "</strong> has been deleted successfully.";
                            resellercontrols_log_action($serviceID, $userid, 'delete_dns_zone', $domain, 'Successfully deleted DNS zone.', 'Success');
                        } else {
                            $reason = resellercontrols_whm_reason($whmResponse);
                            $response['error'] = $reason;
                            resellercontrols_log_action($serviceID, $userid, 'delete_dns_zone', $domain, 'Failed: ' . $reason, 'Failed');
                        }
                    }
                }
            }
        }

        return [
            'templatefile' => 'templates/delete-dns-zone',
            'vars'         => [
                'serviceID' => $serviceID,
                'response'  => $response,
                'token'     => $csrfToken,
            ]
        ];
    }

    // -----------------------------------------------------------------------
    // 2. SHELL ACCESS
    // -----------------------------------------------------------------------
    if ($page === 'shell-access') {
        if (isset($vars['enable_shell_access']) && $vars['enable_shell_access'] !== 'on') {
            return [
                'templatefile' => 'templates/clientarea',
                'vars'         => ['error' => 'The Shell Access feature has been disabled by the administrator.']
            ];
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!resellercontrols_check_token()) {
                $response['error'] = 'Invalid CSRF token. Please reload the page and try again.';
            } else {
                $cpuser = trim($_POST['cpuser']);
                $mode   = isset($_POST['mode']) ? $_POST['mode'] : '';

                if (empty($cpuser)) {
                    $response['error'] = 'Please enter the cPanel username.';
                } elseif (!in_array($mode, ['enable', 'disable'])) {
                    $response['error'] = 'Invalid mode selected.';
                } else {
                    // Security: verify account belongs to this reseller
                    $acctSummary = resellercontrols_call_whm_api(
                        $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                        'accountsummary',
                        ['user' => $cpuser]
                    );

                    if (isset($acctSummary['error'])) {
                        $response['error'] = $acctSummary['error'];
                    } else {
                        // Support both response shapes
                        $acct  = isset($acctSummary['data']['acct'][0]) ? $acctSummary['data']['acct'][0] : (isset($acctSummary['acct'][0]) ? $acctSummary['acct'][0] : null);
                        $owner = $acct ? $acct['owner'] : '';

                        if (empty($owner) && empty($acct)) {
                            $response['error'] = 'Account "' . htmlspecialchars($cpuser) . '" does not exist on this server.';
                        } elseif (
                            strtolower($owner) !== strtolower($service->username) &&
                            strtolower($cpuser) !== strtolower($service->username)
                        ) {
                            $response['error'] = 'Access denied: This cPanel account does not belong to your reseller panel.';
                        } else {
                            $hasshell  = ($mode === 'enable') ? 1 : 0;
                            $shellPath = ($mode === 'enable') ? '/usr/local/cpanel/bin/jailshell' : '/usr/local/cpanel/bin/noshell';

                            $whmResponse = resellercontrols_call_whm_api(
                                $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                                'modifyacct',
                                ['user' => $cpuser, 'HASSHELL' => $hasshell, 'shell' => $shellPath]
                            );

                            if (isset($whmResponse['error'])) {
                                $response['error'] = $whmResponse['error'];
                                resellercontrols_log_action($serviceID, $userid, 'shell_access', $cpuser, 'Connection error: ' . $whmResponse['error'], 'Failed');
                            } elseif (resellercontrols_whm_result_ok($whmResponse)) {
                                $action = ($mode === 'enable') ? 'enabled (Jailshell)' : 'disabled (NoShell)';
                                $response['success'] = "Shell access for user <strong>" . htmlspecialchars($cpuser) . "</strong> has been successfully <strong>{$action}</strong>.";
                                resellercontrols_log_action($serviceID, $userid, 'shell_access', $cpuser, 'Successfully set shell to ' . $action, 'Success');
                            } else {
                                $reason = resellercontrols_whm_reason($whmResponse);
                                $response['error'] = $reason;
                                resellercontrols_log_action($serviceID, $userid, 'shell_access', $cpuser, 'Failed: ' . $reason, 'Failed');
                            }
                        }
                    }
                }
            }
        }

        return [
            'templatefile' => 'templates/shell-access',
            'vars'         => [
                'serviceID' => $serviceID,
                'response'  => $response,
                'token'     => $csrfToken,
            ]
        ];
    }

    // -----------------------------------------------------------------------
    // 3. TRANSFER CPANEL
    // -----------------------------------------------------------------------
    if ($page === 'transfer-cpanel') {
        if (isset($vars['enable_transfer_cpanel']) && $vars['enable_transfer_cpanel'] !== 'on') {
            return [
                'templatefile' => 'templates/clientarea',
                'vars'         => ['error' => 'The Transfer cPanel feature has been disabled by the administrator.']
            ];
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
            if (!resellercontrols_check_token()) {
                $response['error'] = 'Invalid CSRF token. Please reload the page and try again.';
            } else {
                $remoteHost     = trim($_POST['hostname']);
                $remoteUser     = trim($_POST['username']);
                $authType       = 'password';
                $remotePassword = isset($_POST['password']) ? $_POST['password'] : '';

                if (empty($remoteHost) || empty($remoteUser) || empty($remotePassword)) {
                    $response['error'] = 'All fields (remote hostname, cPanel username, and cPanel password) are required.';
                } else {
                    // Build session parameters for standard password-based transfer
                    $sessionParams = [
                        'host'     => $remoteHost,
                        'user'     => $remoteUser,
                        'port'     => 22,
                        'password' => $remotePassword,
                    ];

                    $sessionResponse = resellercontrols_call_whm_api(
                        $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                        'create_remote_user_transfer_session',
                        $sessionParams,
                        60
                    );

                    $sessionId = isset($sessionResponse['data']['transfer_session_id'])
                        ? $sessionResponse['data']['transfer_session_id']
                        : (isset($sessionResponse['transfer_session_id']) ? $sessionResponse['transfer_session_id'] : '');

                    if (empty($sessionId)) {
                        $errMsg = resellercontrols_whm_reason($sessionResponse, 'Could not create transfer session. Check remote server IP/Credentials.');
                        $response['error'] = $errMsg;
                        Capsule::table('mod_resellercontrols_transfers')->insert([
                            'service_id'    => $serviceID,
                            'remote_host'   => $remoteHost,
                            'remote_user'   => $remoteUser,
                            'status'        => 'Failed',
                            'error_message' => $errMsg,
                            'auth_type'     => $authType,
                            'started_at'    => date('Y-m-d H:i:s'),
                            'last_checked_at'=> date('Y-m-d H:i:s'),
                            'completed_at'  => date('Y-m-d H:i:s'),
                        ]);
                    } else {
                        // Enqueue the transfer item
                        $enqueueResponse = resellercontrols_call_whm_api(
                            $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                            'enqueue_transfer_item',
                            [
                                'transfer_session_id' => $sessionId,
                                'module'              => 'AccountRemoteUser',
                                'user'                => $remoteUser,
                                'localuser'           => $remoteUser,
                                'force'               => 1,
                            ],
                            30
                        );

                        if (!resellercontrols_whm_result_ok($enqueueResponse)) {
                            $errMsg = resellercontrols_whm_reason($enqueueResponse, 'Could not enqueue transfer item.');
                            $response['error'] = $errMsg;
                            Capsule::table('mod_resellercontrols_transfers')->insert([
                                'service_id'    => $serviceID,
                                'remote_host'   => $remoteHost,
                                'remote_user'   => $remoteUser,
                                'status'        => 'Failed',
                                'error_message' => $errMsg,
                                'auth_type'     => $authType,
                                'session_id'    => $sessionId,
                                'started_at'    => date('Y-m-d H:i:s'),
                                'last_checked_at'=> date('Y-m-d H:i:s'),
                                'completed_at'  => date('Y-m-d H:i:s'),
                            ]);
                        } else {
                            // Start the transfer session
                            $startResponse = resellercontrols_call_whm_api(
                                $serverIp, $serverUsername, $serverPassword, $serverAccessHash,
                                'start_transfer_session',
                                ['transfer_session_id' => $sessionId],
                                30
                            );

                            if (!resellercontrols_whm_result_ok($startResponse)) {
                                $errMsg = resellercontrols_whm_reason($startResponse, 'Could not start transfer session.');
                                $response['error'] = $errMsg;
                                Capsule::table('mod_resellercontrols_transfers')->insert([
                                    'service_id'    => $serviceID,
                                    'remote_host'   => $remoteHost,
                                    'remote_user'   => $remoteUser,
                                    'status'        => 'Failed',
                                    'error_message' => $errMsg,
                                    'auth_type'     => $authType,
                                    'session_id'    => $sessionId,
                                    'started_at'    => date('Y-m-d H:i:s'),
                                    'last_checked_at'=> date('Y-m-d H:i:s'),
                                    'completed_at'  => date('Y-m-d H:i:s'),
                                ]);
                            } else {
                                // Record the transfer in the database
                                Capsule::table('mod_resellercontrols_transfers')->insert([
                                    'service_id'      => $serviceID,
                                    'remote_host'     => $remoteHost,
                                    'remote_user'     => $remoteUser,
                                    'status'          => 'Running',
                                    'auth_type'       => $authType,
                                    'session_id'      => $sessionId,
                                    'started_at'      => date('Y-m-d H:i:s'),
                                    'last_checked_at' => date('Y-m-d H:i:s'),
                                ]);

                                $response['success'] = "Transfer session successfully started for user <strong>" . htmlspecialchars($remoteUser) . "</strong>. Status updates will appear below.";
                            }
                        }
                    }
                }
            }

            if ($isAjax) {
                header('Content-Type: application/json');
                if (isset($response['error'])) {
                    echo json_encode(['success' => false, 'error' => $response['error']]);
                } else {
                    echo json_encode(['success' => true, 'message' => isset($response['success']) ? $response['success'] : 'Success']);
                }
                exit;
            }
        }

        $transfers = Capsule::table('mod_resellercontrols_transfers')
            ->where('service_id', $serviceID)
            ->orderBy('id', 'desc')
            ->get();

        return [
            'templatefile' => 'templates/transfer-cpanel',
            'vars'         => [
                'serviceID' => $serviceID,
                'response'  => $response,
                'transfers' => $transfers,
                'token'     => $csrfToken,
            ]
        ];
    }

    // -----------------------------------------------------------------------
    // DEFAULT DASHBOARD
    // -----------------------------------------------------------------------
    $controls = [];
    
    if (!isset($vars['enable_delete_dns']) || $vars['enable_delete_dns'] === 'on') {
        $controls[] = [
            'icon'        => 'fa-trash-alt',
            'title'       => 'Delete DNS Zone',
            'description' => 'Delete orphaned DNS zones that belong to terminated domains from your reseller WHM.',
            'link'        => "index.php?m=resellercontrols&page=delete-dns-zone&id={$serviceID}",
            'color'       => 'danger',
        ];
    }
    
    if (!isset($vars['enable_shell_access']) || $vars['enable_shell_access'] === 'on') {
        $controls[] = [
            'icon'        => 'fa-terminal',
            'title'       => 'Shell Access',
            'description' => 'Enable or disable SSH Jailshell access for cPanel accounts under your reseller.',
            'link'        => "index.php?m=resellercontrols&page=shell-access&id={$serviceID}",
            'color'       => 'primary',
        ];
    }
    
    if (!isset($vars['enable_transfer_cpanel']) || $vars['enable_transfer_cpanel'] === 'on') {
        $controls[] = [
            'icon'        => 'fa-file-import',
            'title'       => 'Transfer cPanel',
            'description' => 'Migrate a remote cPanel account into your reseller space via password or access hash.',
            'link'        => "index.php?m=resellercontrols&page=transfer-cpanel&id={$serviceID}",
            'color'       => 'success',
        ];
    }

    return [
        'templatefile' => 'templates/clientarea',
        'vars'         => [
            'serviceID' => $serviceID,
            'controls'  => $controls,
        ]
    ];
}