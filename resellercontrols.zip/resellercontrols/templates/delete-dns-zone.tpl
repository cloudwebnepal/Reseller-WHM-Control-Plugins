{* delete-dns-zone.tpl — IT FOR NEPAL Reseller Controls *}

{if $response.error}
<div class="alert alert-danger">
    <i class="fa fa-exclamation-circle me-2"></i>{$response.error}
</div>
{/if}

{if $response.success}
<div class="alert alert-success">
    <i class="fa fa-check-circle me-2"></i>{$response.success}
</div>
{/if}

<p class="text-muted mb-3">
    Use this tool to delete orphaned DNS zones from your reseller WHM.
    <strong>Only zones that belong to domains in your account can be removed.</strong>
</p>

<form method="post" action="" class="needs-validation" novalidate>
    {* CSRF token — WHMCS injects {$token} automatically; our PHP also passes it *}
    {if $token}
        <input type="hidden" name="token" value="{$token}">
    {/if}

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fa fa-globe me-2 text-primary"></i> Delete DNS Zone
            </h5>
            <span class="badge bg-secondary">Reseller Tool</span>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="domain" class="form-label fw-semibold">Domain Name</label>
                <input type="text" id="domain" name="domain" class="form-control"
                       placeholder="example.com" required autocomplete="off">
                <div class="invalid-feedback">Please enter a valid domain name.</div>
                <div class="form-text text-muted">Enter the domain whose DNS zone you want to delete (must be associated with your account).</div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash-alt me-2"></i> Delete Zone
                </button>
                <a class="btn btn-light" href="index.php?m=resellercontrols&id={$serviceID}">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </a>
            </div>
        </div>
    </div>
</form>

<hr class="my-4">

<div class="card shadow-sm">
    <div class="card-body">
        <h6 class="card-title fw-semibold"><i class="fa fa-info-circle me-1 text-warning"></i> Important Notes</h6>
        <ul class="mb-0 small text-muted">
            <li>DNS zones linked to active cPanel accounts <strong>cannot</strong> be deleted.</li>
            <li>The domain must be associated with your WHMCS account (hosting or registered domain).</li>
            <li>This action is <strong>irreversible</strong> — the zone will be permanently removed from WHM.</li>
        </ul>
    </div>
</div>

{literal}
<style>
.card { border-radius: .5rem; }
.form-label { font-weight: 500; }
.btn-danger { font-weight: 600; }
</style>
{/literal}

{* nonce MUST be OUTSIDE {literal} so Smarty evaluates {$cspNonce} *}
<script nonce="{$cspNonce}">
{literal}
(function () {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.forEach.call(forms, function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
{/literal}
</script>
