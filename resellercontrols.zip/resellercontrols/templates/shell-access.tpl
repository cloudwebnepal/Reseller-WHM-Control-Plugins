{* shell-access.tpl — IT FOR NEPAL Reseller Controls *}

{if $response.error}
<div class="alert alert-danger">
    <i class="fa fa-exclamation-circle me-2"></i>{$response.error}
</div>
{/if}

{if $response.success}
<div class="alert alert-success">
    <i class="fa fa-check-circle me-2"></i>{$response.success}
</div>
{/if}

<p class="text-muted mb-3">
    Enable or disable SSH Jailshell access for a cPanel user under your reseller account.
    <strong>You can only manage accounts that belong to your reseller.</strong>
</p>

<form method="post" action="" class="needs-validation" novalidate>
    {* CSRF token — always pass via $token *}
    {if $token}
        <input type="hidden" name="token" value="{$token}">
    {/if}

    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label for="mode" class="form-label">Shell Access</label>
            <select id="mode" name="mode" class="form-select" required>
                <option value="enable">Enable (Jailshell)</option>
                <option value="disable">Disable (NoShell)</option>
            </select>
            <div class="invalid-feedback">Please select enable or disable.</div>
        </div>

        <div class="col-12 col-md-8">
            <label for="cpuser" class="form-label">cPanel Username</label>
            <input type="text" id="cpuser" name="cpuser" class="form-control"
                   placeholder="e.g. mycpuser" required autocomplete="off">
            <div class="invalid-feedback">Please enter the cPanel username.</div>
            <div class="form-text text-muted">Enter the cPanel username whose shell access you want to modify.</div>
        </div>
    </div>

    <div class="mt-3 d-flex gap-2">
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save me-1"></i> Apply
        </button>
        <a class="btn btn-light" href="index.php?m=resellercontrols&id={$serviceID}">
            <i class="fas fa-arrow-left me-1"></i> Back
        </a>
    </div>
</form>

<hr class="my-4">

<div class="card shadow-sm">
    <div class="card-body">
        <h6 class="card-title fw-semibold"><i class="fa fa-info-circle me-1 text-primary"></i> Notes</h6>
        <ul class="mb-0 small text-muted">
            <li><strong>Jailshell</strong> enables restricted SSH access for the cPanel user (safer than full shell).</li>
            <li><strong>NoShell</strong> completely disables SSH login for the cPanel user.</li>
            <li>Changes take effect immediately on the WHM server.</li>
        </ul>
    </div>
</div>

{literal}
<style>
.nav-tabs .nav-link { font-weight: 500; }
.form-label { font-weight: 500; }
</style>
{/literal}

{* nonce MUST be outside {literal} so Smarty evaluates {$cspNonce} *}
<script nonce="{$cspNonce}">
{literal}
(function () {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (ev) {
            if (!form.checkValidity()) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
{/literal}
</script>
