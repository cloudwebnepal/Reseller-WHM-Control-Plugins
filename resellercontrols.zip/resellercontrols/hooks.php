<?php
/**
 * WHMCS Reseller Controls Client Hooks
 * Developed by Cloud Web Nepal
 * Official Website: https://cloudwebnepal.com
 * Support: +9779845870006
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

// Declare standalone license cache reader helper to avoid requiring resellercontrols.php
if (!function_exists('resellercontrols_get_license_cache')) {
    function resellercontrols_get_license_cache($setting) {
        try {
            if (class_exists('\WHMCS\Database\Capsule') && Capsule::schema()->hasTable('mod_resellercontrols_license')) {
                return Capsule::table('mod_resellercontrols_license')
                    ->where('setting', $setting)
                    ->value('value') ?: '';
            }
        } catch (\Exception $e) {
            // ignore
        }
        return '';
    }
}

/**
 * Inject "Manage Reseller Controls" link into the service details sidebar
 * for Active reseller accounts on cPanel servers.
 */
add_hook('ClientAreaPrimarySidebar', 1, function ($primarySidebar) {
    // Verify license status
    if (function_exists('resellercontrols_get_license_cache')) {
        if (resellercontrols_get_license_cache('status') !== 'active') {
            return;
        }
    }

    $actionsSidebar = $primarySidebar->getChild('Service Details Actions');
    if (is_null($actionsSidebar)) {
        return;
    }

    $service = \Menu::context('service');
    if (!$service instanceof \WHMCS\Service\Service) {
        return;
    }

    if ($service->status !== 'Active') {
        return;
    }

    $product = $service->product;
    if (!$product) {
        return;
    }

    // Only show for reseller accounts on cPanel servers
    if ($product->type !== 'reselleraccount') {
        return;
    }

    // Verify the server module is cPanel
    if ($product->servertype !== 'cpanel') {
        return;
    }

    $actionsSidebar->addChild('ResellerControlsLink', [
        'label' => 'Manage Reseller Controls',
        'uri'   => 'index.php?m=resellercontrols&id=' . $service->id,
        'order' => 20,
        'icon'  => 'fa-cogs',
    ]);
});

/**
 * Inject an "Open Reseller Panel" card on the product details page
 * for Active reseller accounts on cPanel servers.
 */
add_hook('ClientAreaProductDetailsOutput', 1, function ($vars) {
    // Verify license status
    if (function_exists('resellercontrols_get_license_cache')) {
        if (resellercontrols_get_license_cache('status') !== 'active') {
            return;
        }
    }

    $serviceId = isset($vars['serviceid']) ? (int)$vars['serviceid'] : 0;
    if (!$serviceId) {
        return;
    }

    $service = Capsule::table('tblhosting')
        ->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')
        ->where('tblhosting.id', $serviceId)
        ->where('tblhosting.domainstatus', 'Active')
        ->select('tblproducts.type', 'tblproducts.servertype')
        ->first();

    if (!$service) {
        return;
    }

    if ($service->type !== 'reselleraccount') {
        return;
    }

    if ($service->servertype !== 'cpanel') {
        return;
    }

    return '
    <div class="row">
        <div class="col-sm-12">
            <div class="card shadow-sm mb-4" style="border:1px solid #dee2e6;border-radius:.5rem;margin-top:15px;">
                <div class="card-body d-flex flex-column flex-md-row justify-content-between align-items-center text-center text-md-start gap-3" style="padding:1.25rem;">
                    <div>
                        <h5 class="card-title mb-1 fw-bold text-primary" style="font-weight:600;margin-bottom:.25rem;">
                            <i class="fa fa-cogs me-2"></i> Reseller Management Tools
                        </h5>
                        <p class="card-text text-muted mb-0 small" style="font-size:.875rem;">
                            Manage cPanel accounts, SSH shell access, DNS zones, and remote migrations.
                        </p>
                    </div>
                    <div>
                        <a href="index.php?m=resellercontrols&id=' . $serviceId . '" class="btn btn-primary" style="font-weight:500;">
                            <i class="fa fa-external-link-alt me-1"></i> Open Reseller Panel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>';
});